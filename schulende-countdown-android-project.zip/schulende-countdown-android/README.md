# Schulende Countdown – Android APK Build

## Schritt für Schritt
1. Entpacke diese ZIP-Datei.
2. Öffne dein GitHub-Repository im Browser.
3. Klicke **Add file → Upload files**.
4. Lade den **Inhalt** dieses Ordners hoch (nicht nur die ZIP-Datei selbst), inklusive des Ordners `.github/workflows`.
5. Klicke **Commit changes** und bestätige.
6. Öffne im Repository den Reiter **Actions**.
7. Öffne den Workflow **Build Android APK**. Falls noch nicht gelaufen: **Run workflow**.
8. Warte, bis der Workflow grün ist.
9. Öffne den abgeschlossenen Workflow-Lauf und lade unter **Artifacts** die Datei `schulende-countdown-apk` herunter.
10. Entpacke das heruntergeladene Artifact-ZIP und öffne `app-debug.apk` auf deinem Android-Handy, um sie zu installieren.

## Hinweis
Dies ist eine Debug-APK für die direkte Installation auf Android, nicht für den Play Store. Wenn GitHub nach Berechtigungen für Actions fragt, aktiviere Actions für das Repository.
