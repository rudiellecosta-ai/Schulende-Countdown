const TARGET = new Date("2027-06-16T10:00:00+02:00"); // Südtirol: MESZ
const DEFAULT_DAYS_OFF = [
"2026-11-02","2026-11-03","2026-11-04","2026-11-05","2026-11-06",
"2026-12-08",
"2026-12-24","2026-12-25","2026-12-26","2026-12-27","2026-12-28","2026-12-29","2026-12-30","2026-12-31",
"2027-01-01","2027-01-02","2027-01-03","2027-01-04","2027-01-05","2027-01-06",
"2027-02-08","2027-02-09","2027-02-10","2027-02-11","2027-02-12",
"2027-03-19",
"2027-03-25","2027-03-26","2027-03-27","2027-03-28","2027-03-29",
"2027-04-25","2027-05-01","2027-05-06","2027-05-17","2027-06-02"
];
const $ = id => document.getElementById(id);
const pad = n => String(n).padStart(2,"0");
function getDaysOff(){try{const saved=localStorage.getItem("schoolCountdownDaysOff");if(saved!==null)return saved.split(/\s+/).filter(x=>/^\d{4}-\d{2}-\d{2}$/.test(x));}catch(e){}return [...DEFAULT_DAYS_OFF];}
let daysOff = new Set(getDaysOff());
function dateKey(d){return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;}
function countSchoolDays(now){
  // Counts Mon–Fri from today's calendar date through the target date, inclusive.
  const d = new Date(now.getFullYear(),now.getMonth(),now.getDate());
  const end = new Date(2027,5,16);
  let count=0, weekdaysPassed=0;
  while(d<=end){
    const dow=d.getDay(), key=dateKey(d);
    if(dow!==0&&dow!==6){weekdaysPassed++;if(!daysOff.has(key))count++;}
    d.setDate(d.getDate()+1);
  }
  return {count,weekdaysPassed};
}
function render(){
  const now=new Date(), diff=Math.max(0,TARGET-now);
  const totalSeconds=Math.floor(diff/1000);
  const days=Math.floor(totalSeconds/86400), hours=Math.floor(totalSeconds%86400/3600), minutes=Math.floor(totalSeconds%3600/60), seconds=totalSeconds%60;
  $("days").textContent=days.toLocaleString("de-DE");
  $("hours").textContent=pad(hours);$("minutes").textContent=pad(minutes);$("seconds").textContent=pad(seconds);
  const result=countSchoolDays(now);
  $("schoolDays").textContent=result.count.toLocaleString("de-DE");
  const total= countSchoolDays(new Date(2026,8,15)).count;
  const done=Math.max(0,total-result.count);
  const pct=Math.min(100,Math.max(0,Math.round(done/Math.max(1,total)*100)));
  $("progressText").textContent=pct+"%";$("progressBar").style.width=pct+"%";
  $("weeksLeft").textContent=Math.ceil(result.count/5).toLocaleString("de-DE");
  $("holidaysCount").textContent=[...daysOff].filter(k=>{const d=new Date(k+"T12:00:00");return d>=new Date(now.getFullYear(),now.getMonth(),now.getDate())&&d<=new Date(2027,5,16)}).length;
}
function openSettings(){ $("settingsPanel").classList.toggle("hidden");const isOpen=!$("settingsPanel").classList.contains("hidden");$("toggleSettings").setAttribute("aria-expanded",String(isOpen));$("toggleSettings").querySelector("span").textContent=isOpen?"−":"＋";if(isOpen)$("daysOff").value=[...daysOff].sort().join("\n");}
$("toggleSettings").addEventListener("click",openSettings);
$("saveSettings").addEventListener("click",()=>{
  const raw=$("daysOff").value.split(/\s+/).filter(Boolean);
  const valid=raw.filter(x=>/^\d{4}-\d{2}-\d{2}$/.test(x)&&!Number.isNaN(new Date(x+"T12:00:00").getTime()));
  daysOff=new Set(valid);
  try{localStorage.setItem("schoolCountdownDaysOff",[...daysOff].sort().join("\n"));}catch(e){}
  $("saveMessage").textContent=`Gespeichert: ${daysOff.size} schulfreie Daten.`;render();
});
$("resetSettings").addEventListener("click",()=>{daysOff=new Set(DEFAULT_DAYS_OFF);try{localStorage.removeItem("schoolCountdownDaysOff");}catch(e){}$("daysOff").value=[...daysOff].sort().join("\n");$("saveMessage").textContent="Standardkalender wiederhergestellt.";render();});
render();setInterval(render,1000);
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
let deferredPrompt;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;$("installBtn").classList.remove("hidden");});
$("installBtn").addEventListener("click",async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;$("installBtn").classList.add("hidden");});
